<?php

namespace Symfony\Component\Debug\Tests\Fixtures;

/**
 * @deprecated but this is a test
 *             deprecation notice
 * @foobar
 */
interface DeprecatedInterface
{
}
